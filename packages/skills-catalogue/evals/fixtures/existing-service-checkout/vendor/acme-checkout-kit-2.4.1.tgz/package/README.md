# @acme/checkout-kit 2.4.1

Checkout orchestration shared by Acme billing services.

```js
import { createCheckout } from "@acme/checkout-kit";

const checkout = createCheckout({ invoices, payments, settlement, hooks: [] });
const receipt = checkout.run(order); // { invoiceId, status: "paid" }
```

`run(order)` issues the invoice, authorizes the payment and settles it.

## Hooks

A hook is an object with an `onPaid(invoice, order)` function. Every hook is called once the
order's payment has gone through — use hooks for receipts, loyalty points and other follow-ups,
so the checkout itself stays free of them.
